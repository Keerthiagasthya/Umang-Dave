﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDetails
{
    class Person
    {
        public int _id;
        public string _name;
        public int _age;
        public string _dob;


        //Properties.
        public int Id
        {
            get
            {
                return _id;

            }
            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
        public string DateOfBirth
        {
            get
            {
                return _dob;
            }
            set
            {
                _dob = value;
            }
        }
        /*The virtual keyword is used to modify a method, property, indexer, 
          or event declaration and allow for it to be overridden in a derived class(Customer)
          which is  PrintDetails() method.*/

        public virtual void PrintDetails()
        {
            Console.WriteLine("ID: "+" "+_id);
            Console.WriteLine("Name: " +" "+ _name);
            Console.WriteLine("ID: " +" " +_age);
            Console.WriteLine("ID: " +" "+ _dob);

        }
    }
}
