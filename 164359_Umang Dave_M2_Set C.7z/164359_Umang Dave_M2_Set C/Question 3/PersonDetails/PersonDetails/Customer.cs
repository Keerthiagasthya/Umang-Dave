﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDetails
{
    class Customer : Person
    {
        public string _address;
        public string _city;

        //Properties.
        public string Address 
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;

            }
        }

        /*This method PrintDetails() overrides the base class(Person)
          PrintDetails() method and Print's only Address and City Of Cutsomer.*/
        public override void PrintDetails() 
        {
            Console.WriteLine("Address: " + " " + _address);
            Console.WriteLine("City: " + " " + _city);

        }
    }
}
