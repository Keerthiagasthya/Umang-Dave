﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c = new Customer(); //It creates customer class object.
            Console.WriteLine("-------------------Enter Details--------------");

            //Enter Customer Details
            Console.WriteLine("Enter ID:");
            c.Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name:");
            c.Name = Console.ReadLine();
            Console.WriteLine("Enter Age:");
            c.Age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Date Of Birth:");
            c.DateOfBirth = Console.ReadLine();
            Console.WriteLine("Enter Address:");
            c.Address = Console.ReadLine();
            Console.WriteLine("Enter City:");
            c.City = Console.ReadLine();
            Console.WriteLine("-----------Customer Details-----------");
            c.PrintDetails(); //Calls PrintDetails() method.
        }
    }
}
