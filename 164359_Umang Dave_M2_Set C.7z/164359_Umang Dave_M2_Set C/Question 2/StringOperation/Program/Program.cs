﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
        
            var instance = new StringOperation1();
            var type = typeof(StringOperation1);
  
      

            Console.WriteLine("Enter a string");
            string input = Console.ReadLine();
            Console.WriteLine("Enter a character");
            char c = Convert.ToChar(Console.ReadLine());
          


            MethodInfo search = .GetMethod("SearchPosition", BindingFlags.Static | BindingFlags.Public);
            search.Invoke();
          
        }
    }
    public class StringOperation1
    {
        public static int SearchPosition(string input, char serachCriteria)
        {
            int index = input.IndexOf(searchCriteria);
            return index;
        }

    }
}
