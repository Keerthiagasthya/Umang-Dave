﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorMgmtSystem1.Exception1
{
    public class DoctorMgmtSystemException : ApplicationException
    {
        public DoctorMgmtSystemException(): base()
        {

        }

        public DoctorMgmtSystemException(string message): base( message)
        {

        }

        public DoctorMgmtSystemException(string message,Exception objEx): base(message,objEx)
        {

        }
    }
}
