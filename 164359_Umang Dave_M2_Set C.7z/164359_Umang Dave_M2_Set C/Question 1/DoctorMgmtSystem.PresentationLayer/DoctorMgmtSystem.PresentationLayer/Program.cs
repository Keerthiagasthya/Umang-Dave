﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Exceptions;
using DoctorMgmtSystem.Entities;

namespace DoctorMgmtSystem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            char ch;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddInformation();
                        break;
                    case 2:
                        SearchDoctorByRegistrationNo();
                        break;
                    case 3:
                        ListAllGuests();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Enter y to continue or n to exit:");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y');
        }
        private static void AddInformation()
        {
            try
            {
                Doctor doc = new Doctor();
                Console.WriteLine("Enter Registration No. :");
        
                doc.RegisterID= Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Doctor Name :");
                doc.DoctorName = Console.ReadLine();
                Console.WriteLine("Enter City :");
                doc.City= Console.ReadLine();
                Console.WriteLine("Enter Area Of Specialization :");
                doc.Specialization = Console.ReadLine();
                Console.WriteLine("Enter Clinic Address :");
                doc.ClinicAddress = Console.ReadLine();
                Console.WriteLine("Enter Clinic Timings :");
                doc.ClinicTiming = Console.ReadLine();
                Console.WriteLine("Enter Contact No. :");
                doc.DoctorContactNumber = Console.ReadLine();
                

            }
            catch (DoctorMgmtSystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchDoctorByRegistrationNo()
        {
            try
            {
                int searchRegisterID;
                Console.WriteLine("Enter RegisterID to Search:");
                searchRegisterID = Convert.ToInt32(Console.ReadLine());
                Doctor searchDoctor = DoctorBL.SearchDoctorBL(searchRegisterID);
                if (searchGuest != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber\t\trelationship");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}", searchGuest.GuestID, searchGuest.GuestName, searchGuest.GuestContactNumber, searchGuest.Relationship);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (DoctorMgmtSystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    
}
