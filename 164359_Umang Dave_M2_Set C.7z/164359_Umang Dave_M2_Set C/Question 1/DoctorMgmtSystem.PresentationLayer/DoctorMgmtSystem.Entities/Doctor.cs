﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;

namespace DoctorMgmtSystem.Entities
{
    public class Doctor
    {
        private int registerID;

        public int RegisterID
        {
            get
            {
                return registerID;
            }
            set
            {
                registerID = value;
            }
        }
        private string doctorName;

        public string DoctorName
        {
            get
            {
                return doctorName;
            }
            set
            {
                doctorName = value;
            }
        }
        private string doctorContactNumber;

        public string DoctorContactNumber
        {
            get
            {
                return doctorContactNumber;
            }
            set
            {
                doctorContactNumber = value;
            }
        }

        private string city;
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        private string specialization;
        public string Specialization
        {
            get
            {
                return specialization;
            }
            set
            {
                specialization = value;
            }
        }
        private string clinicAddress;
        public string ClinicAddress
        {
            get
            {
                return clinicAddress;
            }
            set
            {
                clinicAddress = value;
            }
        }
        private string clinicTimings;
        public string ClinicTiming
        {
            get
            {
                return clinicTimings;
            }
            set
            {
                clinicTimings = value;
            }
        }

        public Doctor()
        {
            registerID = 0;
            doctorName = string.Empty;
            doctorContactNumber = string.Empty;
            specialization = string.Empty;

            clinicAddress = string.Empty;
            clinicTimings = string.Empty;

        }


    }
}
