﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.Exceptions;

namespace DoctorMgmtSystem.BusinessLayer
{
    public class DoctorBL
    {
        private static bool ValidateGuest(Doctor doctor)
        {
            StringBuilder sb = new StringBuilder();
            bool validInformation = true;
            if (doctor.RegisterID >8)
            {
                validInformation = false;
                sb.Append(Environment.NewLine + "Invalid Registration ID");

            }
            if (doctor.DoctorName == string.Empty)
            {
                validInformation= false;
                sb.Append(Environment.NewLine + "Doctor Name Required");

            }
            if (doctor.DoctorContactNumber.Length < 10)
            {
                validInformation = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if(doctor.Specialization== string.Empty)
            { 
            validInformation = false;
            sb.Append(Environment.NewLine + "Specia");
            }
            
            if (validInformation == false)
                throw new DoctorMgmtSystemException(sb.ToString());
            return validInformation;
        }
        public static Doctor SearchDoctorBL(int searchGuestID)
        {
            Guest searchGuest = null;
            try
            {
                GuestDAL guestDAL = new GuestDAL();
                searchGuest = guestDAL.SearchGuestDAL(searchGuestID);
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchGuest;

        }


    }
}
