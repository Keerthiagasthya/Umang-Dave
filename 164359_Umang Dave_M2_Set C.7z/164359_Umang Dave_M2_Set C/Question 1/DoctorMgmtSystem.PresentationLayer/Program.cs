﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using DoctorMgmtSystem.Entities;
using DoctorMgmtSystem.BL;
using DoctorMgmtSystem1.Exception1;

namespace DoctorMgmtSystem.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {

            SerializeData();
            DeserializeData();
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("enter your choice");
                int operations;
                operations = Convert.ToInt32(Console.ReadLine());
                switch (operations)
                {
                    case 1:
                        //add
                        AddDoctor();
                        break;
                    case 2:
                        //Search
                        SearchDoctor();
                        break;

                    default:
                        Console.WriteLine("");
                        break;
                }
                Console.WriteLine("Do u want to continue");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y' || choice == 'Y');

        }

        static void PrintMenu()
        {
            Console.WriteLine("******Employee Management System******");
            Console.WriteLine("Add 1 to add Employee");
            Console.WriteLine("Add 2 to Search Employee");
        }

        //ADD EMPLOYEE
        static void AddDoctor()
        {
            try
            {
                Doctors objDoctor = new Doctors();
                Console.WriteLine("---------------Enter Doctor Details:----------------- ");
                Console.Write("Enter Registration No. ");
                objDoctor.RegNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Name ");
                objDoctor.Name = Convert.ToChar(Console.ReadLine());
                Console.Write("Enter city ");
                objDoctor.City = Console.ReadLine();
                Console.Write("Enter area of specialization ");
                objDoctor.Area = Convert.ToChar(Console.ReadLine());
                Console.Write("Enter address ");
                objDoctor.Address = Console.ReadLine();
                Console.Write("Enter timings ");
                objDoctor.Timing = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter contact No. ");
                objDoctor.ContactNo = Convert.ToInt32(Console.ReadLine());

                //
                bool drAdded;
                drAdded = DoctorBL.AddDoctorBL(objDoctor);
                if (drAdded)
                {
                    Console.WriteLine(" added successfully");
                }
                else
                {
                    Console.WriteLine(" couldn't be added ");
                }
            }
            catch (DoctorMgmtSystemException objEmpException)
            {
                Console.WriteLine(objEmpException.Message);
            }
        }

        //SEARCH DOCTOR
        static void SearchDoctor()
        {
            try
            {
                int regno;
                Console.Write("Enter Registration no");
                regno = Convert.ToInt32(Console.ReadLine());
                Doctors objDoctor;
                objDoctor = DoctorBL.SearchDoctorBL(regno);
                if (objDoctor != null)
                {
                    Console.WriteLine("---------------Employee DEtails:---------------");
                    Console.WriteLine("Regi no: " + objDoctor.RegNo);
                    Console.WriteLine("Name: " + objDoctor.Name);
                    Console.WriteLine(" city: " + objDoctor.City);
                    Console.WriteLine("area: " + objDoctor.Area);
                    Console.WriteLine("address: " + objDoctor.Address);
                    Console.WriteLine("timings: " + objDoctor.Timing);
                    Console.WriteLine("contactNo: " + objDoctor.ContactNo);
                }
                else
                {
                    Console.WriteLine("data couldn't be found");
                }
            }
            catch (DoctorMgmtSystemException objEmpException)
            {
                Console.WriteLine(objEmpException.Message);
            }

        }

            private static void SerializeData()
            {
                List<Doctors> ContactList = new List<Doctors>();
                string file;
                Console.WriteLine(" enter file location");
                file = Console.ReadLine();
                try
                {
                    Console.WriteLine("Enter number of contacts");
                    int n = int.Parse(Console.ReadLine());

                    for (int index = 0; index < n; index++)
                    {
                        Doctors objDoctor = new Doctors();
                        Console.WriteLine("----------------Enter Doctor Details:-------------- ");
                        Console.Write("Enter Registration No. ");
                        objDoctor.RegNo = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Name ");
                        objDoctor.Name = Convert.ToChar(Console.ReadLine());
                        Console.Write("Enter city ");
                        objDoctor.City = Console.ReadLine();
                        Console.Write("Enter area of specialization ");
                        objDoctor.Area = Convert.ToChar(Console.ReadLine());
                        Console.Write("Enter address ");
                        objDoctor.Address = Console.ReadLine();
                        Console.Write("Enter timings ");
                        objDoctor.Timing = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter contact No. ");
                        objDoctor.ContactNo = Convert.ToInt32(Console.ReadLine());
                        ContactList.Add(objDoctor);
                    }


                    FileStream fileStream = new FileStream(file, FileMode.Create);
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    binaryFormatter.Serialize(fileStream, ContactList);
                    fileStream.Close();
                    Console.Write("Suceessful!!!!!!");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            private static void DeserializeData()
            {
                string file;
                Console.WriteLine(" enter file location");
                file = Console.ReadLine();
                try
                {
                    FileStream fileStream = new FileStream(file, FileMode.Open);
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    List<Doctors> obj = (List<Doctors>)binaryFormatter.Deserialize(fileStream);
                    fileStream.Close();
                    foreach (Doctors c in obj)
                    {
                        Console.WriteLine("Regi No:" + c.RegNo + "Name:" + c.Name + "city" + c.City + "area" + c.Area + "address" + c.Address + "timing" + c.Timing + "contact no:" + c.ContactNo);
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
        }
    }

